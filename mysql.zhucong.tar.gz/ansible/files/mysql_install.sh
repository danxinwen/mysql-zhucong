#!/bin/bash

mysql -uroot -p123456 -e "grant replication slave on *.* to 'dd'@'192.168.227.134' identified by '123456';"
mysql -uroot -p123456 -e 'flush privileges;'
