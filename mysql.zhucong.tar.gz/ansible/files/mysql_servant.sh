#!/bin/bash

mysql -uroot -p123456 -e "change master to master_host='192.168.227.133',master_user='dd',master_password='123456',master_log_file='mysql-bin.000001',master_log_pos=328;"
mysql -uroot -p123456 -e "start slave;"
